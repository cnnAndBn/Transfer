

#export CONFIG_FILE='/root/myWorkBase/code/balanceGS/customConfig/IT/mask_rcnn_r50_fpn.py' 
#export GPU_NUM=1
#export WORK_DIR='/root/myWorkBase/code/balanceGS/workDir/IT/mask_rcnn_r50_fpn/exp1'
#export CHECKPOINT_FILE='/root/myWorkBase/code/balanceGS/workDir/IT/mask_rcnn_r50_fpn/exp1/latest.pth'
#../tools/dist_train.sh ${CONFIG_FILE} ${GPU_NUM} --work_dir ${WORK_DIR}  --validate  --resume_from ${CHECKPOINT_FILE}
#


# export CONFIG_FILE='/root/myWorkBase/code/balanceGS/customConfig/IT/exp2/gs_mask_rcnn_r50_fpn.py' 
# export GPU_NUM=1
# export WORK_DIR='/root/myWorkBase/code/balanceGS/workDir/IT/gs_mask_rcnn_r50_fpn/exp2'
# ##export CHECKPOINT_FILE = ''
# ../tools/dist_train.sh ${CONFIG_FILE} ${GPU_NUM} --work_dir ${WORK_DIR} --validate  #--resume_from ${CHECKPOINT_FILE}
#
#
# export CONFIG_FILE='/root/myWorkBase/code/balanceGS/customConfig/IT/exp2/gs_mask_rcnn_r50_fpn_from_scratch.py' 
# export GPU_NUM=1
# export WORK_DIR='/root/myWorkBase/code/balanceGS/workDir/IT/gs_mask_rcnn_r50_fpn_from_scratch/exp2'
# ##export CHECKPOINT_FILE = ''
# ../tools/dist_train.sh ${CONFIG_FILE} ${GPU_NUM} --work_dir ${WORK_DIR} --validate  #--resume_from ${CHECKPOINT_FILE}
#

#  export CONFIG_FILE='/root/myWorkBase/code/balanceGS/customConfig/IT/exp3/gs_mask_rcnn_r50_fpn.py' 
#  export GPU_NUM=1
#  export WORK_DIR='/root/myWorkBase/code/balanceGS/workDir/IT/gs_mask_rcnn_r50_fpn/exp3'
#  export CHECKPOINT_FILE='/root/myWorkBase/code/balanceGS/workDir/IT/gs_mask_rcnn_r50_fpn/exp3/latest.pth'
#  ../tools/dist_train.sh ${CONFIG_FILE} ${GPU_NUM} --work_dir ${WORK_DIR} --validate  --resume_from ${CHECKPOINT_FILE}


#  export CONFIG_FILE='/root/myWorkBase/code/balanceGS/customConfig/IT/exp4/gs_mask_rcnn_r50_fpn.py' 
#  export GPU_NUM=1
#  export WORK_DIR='/root/myWorkBase/code/balanceGS/workDir/IT/gs_mask_rcnn_r50_fpn/exp4'
#  #export CHECKPOINT_FILE='/root/myWorkBase/code/balanceGS/workDir/IT/gs_mask_rcnn_r50_fpn/exp3/latest.pth'
#  ../tools/dist_train.sh ${CONFIG_FILE} ${GPU_NUM} --work_dir ${WORK_DIR} --validate  #--resume_from ${CHECKPOINT_FILE}
 
 
#  export CONFIG_FILE='/root/myWorkBase/code/balanceGS/customConfig/IT/exp3/gs_mask_rcnn_r50_fpn_albu.py' 
#  export GPU_NUM=1
#  export WORK_DIR='/root/myWorkBase/code/balanceGS/workDir/IT/gs_mask_rcnn_r50_fpn/exp3_albu'
#  export CHECKPOINT_FILE='/root/myWorkBase/code/balanceGS/workDir/IT/gs_mask_rcnn_r50_fpn/exp3_albu/latest.pth'
#  ../tools/dist_train.sh ${CONFIG_FILE} ${GPU_NUM} --work_dir ${WORK_DIR} --validate  --resume_from ${CHECKPOINT_FILE}

#  export CONFIG_FILE='/root/myWorkBase/code/balanceGS/customConfig/IT/exp5/gs_mask_rcnn_r50_fpn.py' 
#  export GPU_NUM=1
#  export WORK_DIR='/root/myWorkBase/code/balanceGS/workDir/IT/gs_mask_rcnn_r50_fpn/exp5'
#  #export CHECKPOINT_FILE='/root/myWorkBase/code/balanceGS/workDir/IT/gs_mask_rcnn_r50_fpn/exp5/latest.pth'
#  ../tools/dist_train.sh ${CONFIG_FILE} ${GPU_NUM} --work_dir ${WORK_DIR} --validate  #--resume_from ${CHECKPOINT_FILE}

#  export CONFIG_FILE='/root/myWorkBase/code/balanceGS/customConfig/IT/exp6/gs_mask_rcnn_r50_fpn.py' 
#  export GPU_NUM=1
#  export WORK_DIR='/root/myWorkBase/code/balanceGS/workDir/IT/gs_mask_rcnn_r50_fpn/exp6'
#  #export CHECKPOINT_FILE='/root/myWorkBase/code/balanceGS/workDir/IT/gs_mask_rcnn_r50_fpn/exp5/latest.pth'
#  ../tools/dist_train.sh ${CONFIG_FILE} ${GPU_NUM} --work_dir ${WORK_DIR} --validate  #--resume_from ${CHECKPOINT_FILE}

# export CONFIG_FILE='/root/myWorkBase/code/balanceGS/customConfig/IT/mask_rcnn_r50_fpn_albu.py' 
# export GPU_NUM=1
# export WORK_DIR='/root/myWorkBase/code/balanceGS/workDir/IT/mask_rcnn_r50_fpn_albu/exp1'
# export CHECKPOINT_FILE='/root/myWorkBase/code/balanceGS/workDir/IT/mask_rcnn_r50_fpn_albu/exp1/latest.pth'
# ../tools/dist_train.sh ${CONFIG_FILE} ${GPU_NUM} --work_dir ${WORK_DIR}  --validate  #--resume_from ${CHECKPOINT_FILE}


# export CONFIG_FILE='/root/myWorkBase/code/balanceGS/customConfig/IT/mask_rcnn_r50_fpn_albu_exp2.py' 
# export GPU_NUM=1
# export WORK_DIR='/root/myWorkBase/code/balanceGS/workDir/IT/mask_rcnn_r50_fpn_albu/exp2'
# export CHECKPOINT_FILE='/root/myWorkBase/code/balanceGS/workDir/IT/mask_rcnn_r50_fpn_albu/exp2/latest.pth'
# ../tools/dist_train.sh ${CONFIG_FILE} ${GPU_NUM} --work_dir ${WORK_DIR}  --validate  #--resume_from ${CHECKPOINT_FILE}

# export CONFIG_FILE='/root/myWorkBase/code/balanceGS/customConfig/IT/v2_data/mask_rcnn_r50_fpn_rfs.py' 
# export GPU_NUM=1
# export WORK_DIR='/root/myWorkBase/code/balanceGS/workDir/IT/V2/mask_rcnn_r50_fpn_rfs/exp2'
# #export CHECKPOINT_FILE='/root/myWorkBase/code/balanceGS/workDir/IT/mask_rcnn_r50_fpn_albu/exp2/latest.pth'
# ../tools/dist_train.sh ${CONFIG_FILE} ${GPU_NUM} --work_dir ${WORK_DIR}  --validate  #--resume_from ${CHECKPOINT_FILE}


# export CONFIG_FILE='/root/myWorkBase/code/balanceGS/customConfig/IT/v2_data/mask_rcnn_r50_fpn.py' 
# export GPU_NUM=1
# export WORK_DIR='/root/myWorkBase/code/balanceGS/workDir/IT/V2/mask_rcnn_r50_fpn/exp2'
# #export CHECKPOINT_FILE='/root/myWorkBase/code/balanceGS/workDir/IT/mask_rcnn_r50_fpn/exp1/latest.pth'
# ../tools/dist_train.sh ${CONFIG_FILE} ${GPU_NUM} --work_dir ${WORK_DIR}  --validate  #--resume_from ${CHECKPOINT_FILE}

#
# export CONFIG_FILE='/root/myWorkBase/code/balanceGS/customConfig/IT/v2_data/cascade_mask_rcnn_r50_fpn.py' 
# export GPU_NUM=2
# export WORK_DIR='/root/myWorkBase/code/balanceGS/workDir/IT/V2/cascade_mask_rcnn_r50_fpn/exp1'
# export CHECKPOINT_FILE='/root/myWorkBase/code/balanceGS/workDir/IT/V2/cascade_mask_rcnn_r50_fpn/exp1/latest.pth'
# ../tools/dist_train.sh ${CONFIG_FILE} ${GPU_NUM} --work_dir ${WORK_DIR} --validate  --resume_from ${CHECKPOINT_FILE}
#
#
#
# export CONFIG_FILE='/root/myWorkBase/code/balanceGS/customConfig/IT/v2_data/mask_rcnn_r50_fpn_ablu.py' 
# export GPU_NUM=2
# export WORK_DIR='/root/myWorkBase/code/balanceGS/workDir/IT/V2/gs_mask_rcnn_r50_fpn_ablu/exp1'
# export CHECKPOINT_FILE='/root/myWorkBase/code/balanceGS/workDir/IT/V2/mask_rcnn_r50_fpn_ablu/exp1/latest.pth'
# ../tools/dist_train.sh ${CONFIG_FILE} ${GPU_NUM} --work_dir ${WORK_DIR} --validate  --resume_from ${CHECKPOINT_FILE}
#


# export CONFIG_FILE='/root/myWorkBase/code/balanceGS/customConfig/IT/v2_data/cascade_mask_rcnn_r50_fpn_cls123.py' 
# export GPU_NUM=2
# export WORK_DIR='/root/myWorkBase/code/balanceGS/workDir/IT/V2/cascade_mask_rcnn_r50_fpn_cls123/exp1'
# export CHECKPOINT_FILE='/root/myWorkBase/code/balanceGS/workDir/IT/V2/cascade_mask_rcnn_r50_fpn_cls123/exp1/latest.pth'
# ../tools/dist_train.sh ${CONFIG_FILE} ${GPU_NUM} --work_dir ${WORK_DIR} --validate  --resume_from ${CHECKPOINT_FILE}




# export CONFIG_FILE='/root/myWorkBase/code/balanceGS/customConfig/IT/v2_data/cascade_mask_rcnn_r50_fpn_cls120.py' 
# export GPU_NUM=2
# export WORK_DIR='/root/myWorkBase/code/balanceGS/workDir/IT/V2/cascade_mask_rcnn_r50_fpn_cls120/exp1'
# export CHECKPOINT_FILE='/root/myWorkBase/code/balanceGS/workDir/IT/V2/cascade_mask_rcnn_r50_fpn_cls120/exp1/latest.pth'
# ../tools/dist_train.sh ${CONFIG_FILE} ${GPU_NUM} --work_dir ${WORK_DIR} --validate  #--resume_from ${CHECKPOINT_FILE}


#export CONFIG_FILE='/root/myWorkBase/code/balanceGS/customConfig/IT/v2_data/cascade_mask_rcnn_r50_fpn_rfs_cls123.py' 
#export GPU_NUM=2
#export WORK_DIR='/root/myWorkBase/code/balanceGS/workDir/IT/V2/cascade_mask_rcnn_r50_fpn_rfs_cls123/exp1'
#export CHECKPOINT_FILE='/root/myWorkBase/code/balanceGS/workDir/IT/V2/cascade_mask_rcnn_r50_fpn_rfs_cls123/exp1/latest.pth'
#../tools/dist_train.sh ${CONFIG_FILE} ${GPU_NUM} --work_dir ${WORK_DIR} --validate  --resume_from ${CHECKPOINT_FILE}
#




# export CONFIG_FILE='/root/myWorkBase/code/balanceGS/customConfig/IT/v2_data/gs_cascade_mask_rcnn_r50_fpn_cls123_exp5.py' 
# export GPU_NUM=2
# export WORK_DIR='/root/myWorkBase/code/balanceGS/workDir/IT/V2/gs_cascade_mask_rcnn_r50_fpn_cls123/exp5'
# #export CHECKPOINT_FILE='/root/myWorkBase/code/balanceGS/workDir/IT/V2/gs_cascade_mask_rcnn_r50_fpn_cls123/exp1/latest.pth'
# ../tools/dist_train.sh ${CONFIG_FILE} ${GPU_NUM} --work_dir ${WORK_DIR} --validate # --resume_from ${CHECKPOINT_FILE} 


export CONFIG_FILE='/root/myWorkBase/code/balanceGS/customConfig/IT/v2_data/gs_cascade_mask_rcnn_r50_fpn_cls123_exp6.py' 
export GPU_NUM=2
export WORK_DIR='/root/myWorkBase/code/balanceGS/workDir/IT/V2/gs_cascade_mask_rcnn_r50_fpn_cls123/exp6'
export CHECKPOINT_FILE='/root/myWorkBase/code/balanceGS/workDir/IT/V2/gs_cascade_mask_rcnn_r50_fpn_cls123/exp6/latest.pth'
../tools/dist_train.sh ${CONFIG_FILE} ${GPU_NUM} --work_dir ${WORK_DIR} --validate  --resume_from ${CHECKPOINT_FILE} 

# # #######################################################

export CONFIG_FILE='/root/myWorkBase/code/balanceGS/customConfig/IT/mask_rcnn_r50_fpn_albu_exp2_infi.py' 
export GPU_NUM=2
export WORK_DIR='/root/myWorkBase/code/balanceGS/workDir/IT/infi'
 #export CHECKPOINT_FILE='/root/myWorkBase/code/balanceGS/workDir/IT/mask_rcnn_r50_fpn_albu/exp2/latest.pth'
../tools/dist_train.sh ${CONFIG_FILE} ${GPU_NUM} --work_dir ${WORK_DIR}  --validate  #--resume_from ${CHECKPOINT_FILE}
