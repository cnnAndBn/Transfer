# export CONFIG_FILE='/root/myWorkBase/code/balanceGS/customConfig/IT/exp3/gs_mask_rcnn_r50_fpn.py'
# export CHECKPOINT='/root/myWorkBase/code/balanceGS/workDir/IT/gs_mask_rcnn_r50_fpn/exp3/epoch_7.pth'
# export IMG_DIR='/root/myWorkBase/code/balanceGS/data/IT/v1/val'
# export VIS_DIR='/root/myWorkBase/code/balanceGS/workDir/visualization_val'
# export RESULT_PATH='/root/myWorkBase/code/balanceGS/workDir/exp3_valset_result_with_prob.json'
# export THRESHOLD=0.72

# python ../tools/test_visulize.py ${CONFIG_FILE} ${CHECKPOINT} ${IMG_DIR} ${VIS_DIR} ${RESULT_PATH} --score-thr ${THRESHOLD}


export CONFIG_FILE='/root/myWorkBase/code/balanceGS/customConfig/IT/v2_data/cascade_mask_rcnn_r50_fpn.py' 
export CHECKPOINT='/root/myWorkBase/code/balanceGS/workDir/IT/V2/cascade_mask_rcnn_r50_fpn/exp1/epoch_48.pth'
export IMG_DIR='/root/myWorkBase/code/balanceGS/data/IT/v2/val'
export VIS_DIR='/root/myWorkBase/code/balanceGS/workDir/visualization_v2_val'
export RESULT_PATH='/root/myWorkBase/code/balanceGS/workDir/v2_valset_result_with_prob.json'
export THRESHOLD=0.72

python ../tools/test_visulize.py ${CONFIG_FILE} ${CHECKPOINT} ${IMG_DIR} ${VIS_DIR} ${RESULT_PATH} --score-thr ${THRESHOLD}