export CONFIG_FILE="/root/myWorkBase/code/balanceGS/customConfig/IT/v2_data/gs_cascade_mask_rcnn_r50_fpn_cls123_exp3.py"
export CHECKPOINT="/root/myWorkBase/code/balanceGS/workDir/IT/V2/gs_cascade_mask_rcnn_r50_fpn_cls123/exp3/epoch_47.pth"
export GPU_NUM=2
export EVAL_TYPE="bbox"  #bbox segm
../tools/dist_test.sh ${CONFIG_FILE} \
   ${CHECKPOINT} \
   ${GPU_NUM}   --eval ${EVAL_TYPE} --out results.pkl


