export CONFIG_FILE='/root/myWorkBase/code/balanceGS/customConfig/IT/v2_data/mask_rcnn_r50_fpn.py'
export CHECKPOINT='/root/myWorkBase/code/balanceGS/workDir/IT/V2/mask_rcnn_r50_fpn/exp2/epoch_49.pth'
export IMG_DIR='/root/myWorkBase/code/balanceGS/data/IT/v2/val'
export VIS_DIR='/root/myWorkBase/code/balanceGS/workDir/cat_vis_v2_val'
export CAT_SHOW='4,3'
export CAT_THR='0.06,0.375'



python ../tools/cls_vis.py ${CONFIG_FILE} ${CHECKPOINT} ${IMG_DIR} ${VIS_DIR} ${CAT_SHOW} ${CAT_THR}
