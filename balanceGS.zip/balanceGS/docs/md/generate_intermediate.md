# How to generate intermediate files

TO BE COMPLETE.
Refer to `tools/lvis_analyse.py`