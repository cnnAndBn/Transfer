# GENERATED VERSION FILE
# TIME: Thu Oct 22 14:56:47 2020

__version__ = '1.0.rc0+unknown'
short_version = '1.0.rc0'
