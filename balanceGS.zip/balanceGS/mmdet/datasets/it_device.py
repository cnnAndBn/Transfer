from .registry import DATASETS
from .lvis import LvisDataset
from lvis.lvis import LVIS
from .coco import CocoDataset

@DATASETS.register_module
class GS_ItDeviceDataset(LvisDataset):

    def load_annotations(self, ann_file):
        self.lvis = LVIS(ann_file)
        self.full_cat_ids = self.lvis.get_cat_ids()
        self.full_cat2label = {
            cat_id: i + 1
            for i, cat_id in enumerate(self.full_cat_ids)
        }

        self.CLASSES = tuple([item['name'] for item in self.lvis.dataset['categories']])
        self.cat_ids = self.lvis.get_cat_ids()
        self.cat2label = {
            cat_id: i + 1
            for i, cat_id in enumerate(self.cat_ids)
        }

        self.img_ids = self.lvis.get_img_ids()
        img_infos = []
        for i in self.img_ids:
            info = self.lvis.load_imgs([i])[0]
            info['filename'] = info['file_name']   #for group softmax
            img_infos.append(info)
        return img_infos


@DATASETS.register_module  
class ItDeviceDataset(CocoDataset):
    CLASSES = ('back', 'officialFront', 'personalFront', 'blackFront', 'others')