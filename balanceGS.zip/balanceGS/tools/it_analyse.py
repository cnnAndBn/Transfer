from lvis.lvis import LVIS
import numpy as np
import pickle
import pdb
import os
import json
import torch
from pycocotools.coco import COCO



def get_cate_gs_it_company():

    train_ann_file = '../data/IT/v2/train_gsoftmax.json'
    lvis_train = LVIS(train_ann_file)
    train_catsinfo = lvis_train.cats

    binlabel_count = [1, 1, 1, 1]
    label2binlabel = np.zeros((4, 6), dtype=np.int)   #分成4个group，实际一共6类(bg+5fg)

    label2binlabel[0, 1:] = binlabel_count[0]
    binlabel_count[0] += 1

    for cid, cate in train_catsinfo.items():
        ins_count = cate['instance_count']
        if ins_count < 500:
            label2binlabel[1, cid] = binlabel_count[1]
            binlabel_count[1] += 1
        elif ins_count < 1000:
            label2binlabel[2, cid] = binlabel_count[2]
            binlabel_count[2] += 1
        else:
            label2binlabel[3, cid] = binlabel_count[3]
            binlabel_count[3] += 1


    savebin = torch.from_numpy(label2binlabel)

    save_path = '../data/IT/v2/train_label2binlabel.pt'
    torch.save(savebin, save_path)

    # start and length
    pred_slice = np.zeros((4, 2), dtype=np.int)  #(group num,2)
    start_idx = 0
    for i, bincount in enumerate(binlabel_count):
        pred_slice[i, 0] = start_idx
        pred_slice[i, 1] = bincount
        start_idx += bincount

    savebin = torch.from_numpy(pred_slice)
    save_path = '../data/IT/v2/pred_slice_with0.pt'
    torch.save(savebin, save_path)

    # pdb.set_trace()

    return pred_slice

def get_split_it_company():

    train_ann_file = '../data/IT/v2/train_gsoftmax.json'
    val_ann_file = '../data/IT/v2/val.json'

    # For training set
    lvis_train = LVIS(train_ann_file)
    # lvis_val = LVIS(val_ann_file)
    train_catsinfo = lvis_train.cats
    # val_catsinfo = lvis_val.cats

    bin500 = []
    bin1000 = []
    binover = []

    for cid, cate in train_catsinfo.items():
        ins_count = cate['instance_count']
        if ins_count < 500:
            bin500.append(cid)
        elif ins_count < 1000:
            bin1000.append(cid)
        else:
            binover.append(cid)

    splits = {}
    splits['(0, 500)'] = np.array(bin500, dtype=np.int)
    splits['[500, 1000)'] = np.array(bin1000, dtype=np.int)
    splits['[1000, ~)'] = np.array(binover, dtype=np.int)
    splits['normal'] = np.arange(1, 5)
    splits['background'] = np.zeros((1,), dtype=np.int)
    splits['all'] = np.arange(6)
    split_file_name = '../data/IT/v2/trainsplit.pkl'
    with open(split_file_name, 'wb') as f:
        pickle.dump(splits, f)


if __name__ == '__main__':
   get_cate_gs_it_company()
   get_split_it_company()
