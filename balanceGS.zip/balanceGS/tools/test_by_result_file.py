import os
import os.path as osp
import json
from pycocotools.coco import COCO
import numpy as np
from mmdet.core import results2json,coco_eval
from mmdet.core.evaluation.coco_utils import xyxy2xywh
from mmdet.datasets import build_dataset
import mmcv
from pycocotools.cocoeval import COCOeval

def convertFormatIT(resultSet,gtSet):
    '''
    将粗定位和细分类的结果合并，并转换为pycocotools中COCOeval类的兼容输入
    Args:
        resultSet:
    Returns:
    '''
    #clsIdMap = {3:103,4:104,5:105} 
    clsIdMap = {3:121,4:122,5:123} 

    imgs = gtSet.imgs
    catsNum = len(gtSet.cats)
    print('Fg category num {}'.format(catsNum))
    r = np.array([])[:, np.newaxis]
    t = np.concatenate((r, r, r, r, r), axis=1)  #最终的结果 [x1,y1,x2,y2,prob]

    
    imgnameToId = {}
    for id,(imgId,imgInfo) in enumerate(imgs.items()):
        imgnameToId[imgInfo['file_name']] = id   #gt 中的顺序
    
    print('>>>>>>> {}'.format(len(imgnameToId)))


    convertedResult = {}
    for imgName,imgResult in resultSet.items():
        
        if ' ' in imgName:
            imgName = '_'.join(imgName.split(' '))
        if imgName not in list(imgnameToId.keys()):   #测试是根据图片来跑的结果，而其中有些图ground truth可能没有标注，因此跳过
            print(imgName)
            continue
        
        imgSeqId = imgnameToId[imgName]

        resultTemp = [t for _ in range(catsNum)]
        convertedResult[imgSeqId] = resultTemp


        for objResult in imgResult:
            
            
            x1,y1,x2,y2 = objResult[:4]  #x1,y1,x2,y2
            detProb = objResult[4]
            detCls = objResult[5]
            fineCls = objResult[6]
            fineProb = objResult[7]


            #修改类别和score
            if detCls in list(clsIdMap.keys()): #当定位粗分类为personalFront,blackFront,others 三类时
                finalCls = clsIdMap[detCls]
                finalProb = detProb

            else:     #当有细分结果情况下
                
                if fineCls !=-1 and fineCls !=-2:
                   finalCls = fineCls
                   finalProb = fineProb*detProb
                
                else:
                    continue
                

            resultTemp[finalCls - 1] = np.row_stack((resultTemp[finalCls - 1], np.array([ x1,y1,x2,y2,finalProb])[np.newaxis,:]))  #TODO:确认预测类别的起始index-->fg from index 1

        convertedResult[imgSeqId] = resultTemp
    
    print('***** {}'.format(len(convertedResult)))
    finalResult = []
    for imgId in range(len(convertedResult)):   
#         if imgId not in list(convertedResult.keys()):
#                  continue
        finalResult.append(convertedResult[imgId])

    return finalResult


def det2json(dataset, results):
    json_results = []
    for idx in range(len(dataset.imgs)):
        img_id = dataset.getImgIds()[idx]
        
        result = results[idx]
        for label in range(len(result)):
            bboxes = result[label]
            for i in range(bboxes.shape[0]):
                data = dict()
                data['image_id'] = img_id
                data['bbox'] = xyxy2xywh(bboxes[i])
                data['score'] = float(bboxes[i][4])
                data['category_id'] = dataset.getCatIds()[label]
                json_results.append(data)
    return json_results


def coco_eval(resultPath, result_types, coco, max_dets=(100, 300, 1000)):
    for res_type in result_types:
        assert res_type in [
            'bbox', 'segm',
        ]

        if not osp.exists(resultPath):
            raise FileNotFoundError('{} not found.'.format(resultPath))


        coco_dets = coco.loadRes(resultPath)
        img_ids = coco.getImgIds()
        iou_type = 'bbox' if res_type == 'proposal' else res_type
        cocoEval = COCOeval(coco, coco_dets, iou_type)
        cocoEval.params.imgIds = img_ids

        cocoEval.params.maxDets=[1,10,100]
        print('eval All:')
        cocoEval.evaluate()
        cocoEval.accumulate()
        cocoEval.summarize()
        
        recall_to_see = [1.0, 0.95, 0.9,'AP','AR']  # The max recall under which to see the precision of each class
        for i, r in enumerate(recall_to_see):
            if i<3:
                key = '\nMaxRecall_{:.2f}\n'.format(r)
                val = cocoEval.details[i]
                print(key)
                print(val)
            else:
                print(r)
                print(cocoEval.details[i])

if __name__ == '__main__':

    valJsonPath = '/root/myWorkBase/data/IT/v2/val_v2_fineCls.json'
    #resultJsonPath = '/root/myWorkBase/code/balanceGS/workDir/v2_valset_results_fineCls.json'
    resultJsonPath = '/root/myWorkBase/code/balanceGS/workDir/v2_valset_results__fineCls_174.json'

    if not osp.exists(valJsonPath) or not osp.exists(resultJsonPath):
        raise FileNotFoundError('{} or {} not exist '.format(valJsonPath,resultJsonPath))

    gtSet = COCO(valJsonPath)

    with open(resultJsonPath, 'r', encoding='UTF-8') as load_f:
        resultSet = json.load(load_f)

    convertedResultSet = convertFormatIT(resultSet,gtSet)
    result = det2json(gtSet,convertedResultSet)
    mmcv.dump(result,'./.temp.json')
    coco_eval('./.temp.json', ['bbox'], gtSet)

