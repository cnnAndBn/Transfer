from lvis.lvis import LVIS
import numpy as np
import pickle
import pdb
import os
import json
import torch
from pycocotools.coco import COCO



def get_cate_gs_it_company():

    train_ann_file = r'/root/myWorkBase/code/balanceGS/data/IT/v2/train_gsoftmax_v2_123cls.json'
    lvis_train = LVIS(train_ann_file)
    train_catsinfo = lvis_train.cats

    binlabel_count = [1, 1, 1, 1,1,1]
    label2binlabel = np.zeros((6, 124), dtype=np.int)   #分成4个group，实际一共124类(bg+123fg)

    label2binlabel[0, 1:] = binlabel_count[0]
    binlabel_count[0] += 1

    for cid, cate in train_catsinfo.items():
        ins_count = cate['instance_count']
        if ins_count <=30:
            label2binlabel[1, cid] = binlabel_count[1]
            binlabel_count[1] += 1
        elif ins_count <=50:
            label2binlabel[2, cid] = binlabel_count[2]
            binlabel_count[2] += 1
        elif ins_count <= 70:
            label2binlabel[3, cid] = binlabel_count[3]
            binlabel_count[3] += 1
        elif ins_count <= 200:
            label2binlabel[4, cid] = binlabel_count[4]
            binlabel_count[4] += 1
        else:
            label2binlabel[5, cid] = binlabel_count[5]
            binlabel_count[5] += 1


    savebin = torch.from_numpy(label2binlabel)

    save_path = 'label2binlabel_v2_123cls.pt'
    torch.save(savebin, save_path)

    # start and length
    pred_slice = np.zeros((6, 2), dtype=np.int)  #(group num,2)
    start_idx = 0
    for i, bincount in enumerate(binlabel_count):
        pred_slice[i, 0] = start_idx
        pred_slice[i, 1] = bincount
        start_idx += bincount

    savebin = torch.from_numpy(pred_slice)
    save_path = 'pred_slice_with0_v2_cls123.pt'
    torch.save(savebin, save_path)

    return pred_slice




def get_split_it_company():

    train_ann_file =r'/root/myWorkBase/code/balanceGS/data/IT/v2/train_gsoftmax_v2_123cls.json'


    # For training set
    lvis_train = LVIS(train_ann_file)

    train_catsinfo = lvis_train.cats


    bin30 = []
    bin50 = []
    bin70 = []
    bin200 = []
    binover = []

    for cid, cate in train_catsinfo.items():
        ins_count = cate['instance_count']
        if ins_count <= 30:
            bin30.append(cid)
        elif ins_count <=50:
            bin50.append(cid)
        elif ins_count <=70:
            bin70.append(cid)
        elif ins_count <= 200:
            bin200.append(cid)
        else:
            binover.append(cid)



    splits = {}
    splits['(0, 30]'] = np.array(bin30, dtype=np.int)
    splits['(30, 50]'] = np.array(bin50, dtype=np.int)
    splits['(50, 70]'] = np.array(bin70, dtype=np.int)
    splits['(70, 200]'] = np.array(bin200, dtype=np.int)
    splits['(200, ~)'] = np.array(binover, dtype=np.int)

    splits['normal'] = np.arange(1, 123)
    splits['background'] = np.zeros((1,), dtype=np.int)
    splits['all'] = np.arange(124)
    split_file_name = 'trainsplit_v2_123cls.pkl'
    with open(split_file_name, 'wb') as f:
        pickle.dump(splits, f)




if __name__ == '__main__':
    get_cate_gs_it_company()
    get_split_it_company()

    # lvis_train = LVIS(r'C:\Users\cmri\Desktop\BalancedGroupSoftmax-master\BalancedGroupSoftmax-master\data\cellphone\train_gsoftmax.json')
    # train_catsinfo = lvis_train.cats
    #
